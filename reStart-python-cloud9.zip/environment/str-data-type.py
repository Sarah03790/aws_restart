# myStr= "MY NAME IS SARAH!"

# print(myStr)

# print(type(myStr))

# print(myStr + " is of data type" + str(type(myStr)))

# Str_1= "python is "
# Str_2= "fun"
# Str_3= Str_1+Str_2
# print(Str_3)

name= input("what is your name? ")

print(name)


