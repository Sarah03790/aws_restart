import csv
import copy

my_vehicle= {
    "vin": "<empty>",
    "make": "<empty>",
    "model": "<empty>",
    "year" : 0 ,
    "range": 0,
    "topSpeed":0,
    "zeroSixty":0.0,
    "mileage":0
}

for key, value in my_vehicle.items():
    print("{} : {} ".format(key,value))

my_invantory_list= []

with open('car_fleet.csv') as csvFile:
    csvReader= csv.reader(csvFile, delimiter=',')
    lineCount=0
    for row in csvReader:
        if lineCount==0:
            print(f'colum names are: {", ".join(row)}')
            lineCount +=1
        else:
            print(f'vin: {row[0]make: {row[1]}, model: {row[2]}, year: {row[3]}, range: {row[4]}, topSpeed: {row[5]}, zeroSixty: {row[6]}, mileage: {row[7]}')
            current_vehical= copy.deepcopy(my_vehicle)
            current_vehical["vin"]=row[0]
            current_vehical["make"]=row[1]
            current_vehical["model"]=row[2]
            current_vehical["year"]=row[3]
            current_vehical["range"]=row[4]
            current_vehical["topSpeed"]=row[5]
            current_vehical["zeroSixty"]=row[6]
            current_vehical["mileage"]=row[7]
            my_invantory_list.append(current_vehical)
            lineCount +=1
    print(f'processed {lineCount} lines.')
    current_vehical=copy.deepcopy(my_vehicle)
    
for my_car_properties in my_invantory_list:
     for key, value in my_car_properties.item():
          print("{} : {}".format(key,value))
          print("------")
     