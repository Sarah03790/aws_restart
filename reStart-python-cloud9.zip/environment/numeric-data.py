print("python has three numeric types: int, float, and complex")

myVal=6
print(myVal)

print(type(myVal))

print(str(myVal) + " is of the data type " + str(type(myVal)))

myVal=6.69
print(myVal)

print(type(myVal))

print(str(myVal) + " is of the data type " + str(type(myVal)))

myVal=6j

print(myVal)

print(type(myVal))

print(str(myVal) + " is of the data type " + str(type(myVal)))

myVal=True
print(myVal)

print(type(myVal))

print(str(myVal) + " is of the data type " + str(type(myVal)))

myVal=False
print(myVal)

print(type(myVal))

print(str(myVal) + " is of the data type " + str(type(myVal)))