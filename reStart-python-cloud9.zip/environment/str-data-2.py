myStr= "MY NAME IS SARAH!"

print(myStr)

print(type(myStr))

print(myStr + " is of data type" + str(type(myStr)))

Str_1= "python is "
Str_2= "fun"
Str_3= Str_1+Str_2
print(Str_3)

name= input("what is your name? ")

print(name)

color= input("what is your favorite color? ")
animal= input("what is your favorit animal? ")

print(" {}, you like a {} {}!" .format(name,color,animal))

