my_mix_list=[45,209471,1.69,True,"my cat's name is Snowy ","24"]

for item in my_mix_list:
    print("{} is of the data type {}".format(item,type(item)))
    
