user_reply= input("do you need to ship a package? (enter yes or no) ")

if user_reply == "yes":
    print("we can help you ship that package!")
    
elif user_reply == "no":
    print("pleas come back when you need to ship a package. thank you")

else:
    print("error come back again")

user_reply= input("would you like to buy stamps, envelope, or make a copy? (enter stamp, envelope, or copy) ")

if user_reply == "stamp":
    print("we have different designs to choose from")
elif user_reply == "envelope":
    print("we have different sizes to choose from")
elif user_reply == "copy":
    copies= input("how many copies would you like? (enter a number)")
    print("here are {} copies ".format(copies))
else:
    print("thank you please come again")