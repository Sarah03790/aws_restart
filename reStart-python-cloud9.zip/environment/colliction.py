# #list
# my_fruit_list= ["apple","banana","cherry"]
# print(my_fruit_list)
# print(type(my_fruit_list))

# print(my_fruit_list[0])
# print(my_fruit_list[1])
# print(my_fruit_list[2])

# my_fruit_list[2]= "melon"

# print(my_fruit_list)

# # tuple
# my_fruit_tuple= ("apple","banana","pineapple")
# print(my_fruit_tuple)
# print(type(my_fruit_tuple))

# print(my_fruit_tuple[0])
# print(my_fruit_tuple[1])
# print(my_fruit_tuple[2])

# #dictionary 

# my_favorit_fruit_dictionary= {
#     "sara":"melon",
#     "lulu":"cherry",
#     "noor":"banana"
# }

# print(my_favorit_fruit_dictionary)
# print(type(my_favorit_fruit_dictionary))

# print(my_favorit_fruit_dictionary["lulu"])

phone_num= [{
    "hani":"584038569",
    "lulu":"3049583020"
},{
    "sarah":"200394832",
    "lulu2":"398458643"
}]

print(phone_num)


