import random

print("welcom to guess the numbe!")
print("the ruls are simple i will think of a number and you will try to guess it")

num= random.randint(1,10)

#to track if the user guessed right

is_guess_right= False

# the games logic

while is_guess_right != True:
    guess= input("guess a number between 1 and 10: ")
    if int(guess)== num:
        print("you guessed {}. that is correct!, you win".format(guess))
        is_guess_right= True
    else:
        print("you guessed {}. that is wrong!, you lose".format(guess))